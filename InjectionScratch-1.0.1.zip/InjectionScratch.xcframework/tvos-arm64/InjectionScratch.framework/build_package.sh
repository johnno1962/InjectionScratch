#!/bin/bash -x

# See: https://developer.apple.com/documentation/swift_packages/distributing_binary_frameworks_as_swift_packages

VERS=${1:?Version }

rm -rf Device Simulator InjectionScratch*.{xcframework,zip} &&

xcodebuild archive -scheme InjectionScratch -destination "generic/platform=iOS" -archivePath Device -project InjectionScratch.xcodeproj &&
xcodebuild archive -scheme InjectionScratch -destination "generic/platform=iOS Simulator" -archivePath Simulator -project InjectionScratch.xcodeproj &&
xcodebuild SDKROOT=appletvos TARGETED_DEVICE_FAMILY=3 archive -scheme InjectionScratchTV -destination "generic/platform=tvOS" -archivePath DeviceTV -project InjectionScratchTV.xcodeproj &&
xcodebuild SDKROOT=appletvsimulator TARGETED_DEVICE_FAMILY=3 archive -scheme InjectionScratchTV -destination "generic/platform=tvOS Simulator" -archivePath SimulatorTV -project InjectionScratchTV.xcodeproj &&

xcodebuild -create-xcframework -framework Device.xcarchive/Products/Library/Frameworks/InjectionScratch.framework -framework Simulator.xcarchive/Products/Library/Frameworks/InjectionScratch.framework -framework DeviceTV.xcarchive/Products/Library/Frameworks/InjectionScratch.framework -framework SimulatorTV.xcarchive/Products/Library/Frameworks/InjectionScratch.framework -output InjectionScratch.xcframework &&

zip -r InjectionScratch-$1.zip InjectionScratch.xcframework &&

echo "Checksum to update in Package.swift:" &&
swift package compute-checksum InjectionScratch-$1.zip

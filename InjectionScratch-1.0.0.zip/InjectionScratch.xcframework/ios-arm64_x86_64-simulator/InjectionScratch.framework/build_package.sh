#!/bin/bash -x

# See: https://developer.apple.com/documentation/swift_packages/distributing_binary_frameworks_as_swift_packages

VERS=${1:?Version }

rm -rf Device Simulator InjectionScratch*.{xcframework,zip} &&

xcodebuild archive -scheme InjectionScratch -destination "generic/platform=iOS" -archivePath Device &&
xcodebuild archive -scheme InjectionScratch -destination "generic/platform=iOS Simulator" -archivePath Simulator &&

xcodebuild -create-xcframework -framework Device.xcarchive/Products/Library/Frameworks/InjectionScratch.framework -framework Simulator.xcarchive/Products/Library/Frameworks/InjectionScratch.framework -output InjectionScratch.xcframework &&

zip -r InjectionScratch-$1.zip InjectionScratch.xcframework &&

echo "Checksum to update in Package.swift:" &&
swift package compute-checksum InjectionScratch-$1.zip
